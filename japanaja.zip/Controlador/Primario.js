var Operaciones=require('./../Modelo/Operaciones')
const DireccionPaginas={
	'PublicarAhorro':'Vista/quiero-ahorrar.ejs',
	'MisPropuestas':'Vista/tus-propuestas-opciones.ejs',
	'EligirAhorro':'Vista/quiero-efectivo.ejs'
}

class Primario {

static  MisPropuestas(req,res){
      console.log(req.session);
      if(!req.session.ide){
        res.redirect(302,"/");
        res.end();
        return;
      }
  		var config={
              'name':req.session.config.name||'',
              'perfil':req.session.config.perfil
             }; 

		    Operaciones.CargarOpcionesXUsuario(req.session.ide,(err,OA)=>{
             
          config.OpcionesActivas=OA;
         Operaciones.CargarPropuestasxUsuario(req.session.ide,(err,PA)=>{
            config.PropuestasActivas=PA;
           Operaciones.CargarPropuestasCompletadosxUsuario(req.session.ide,(err,PR)=>{
                 console.log(config);
                 config.PropuestasRealisadas=PR;
                 Operaciones.CargarOpcionesCompletadosxUsuario(req.session.ide,(err,OR)=>{
                  config.OpcionesCompletadas=OR;
                 res.render(DireccionPaginas.MisPropuestas,config);
                 });

                  })
             });
		    })
		    
 }
static lanzarOpcion(req,res){

   
}
static PublicarAhorro(req,res){
	if(!req.session.ide){
      res.redirect(302,'/');
		return;
	}


  Operaciones.CargarTipos((err,data)=>{
  console.log(data);
   	if (req.session.ide){
	 req.session.config.tipos=data;
     res.render(DireccionPaginas.PublicarAhorro,req.session.config);
     return;
	}
 
  let config={
  	'name':"Publicar Ahorro",
  	'logeadoClass':'notLogged',
  	'tipos':data||[]
  };
  
	res.render(DireccionPaginas.PublicarAhorro,config);

  })

    }

static ElegirAhorro(req,res){
 req.session.url = "/QuieroEfectivo";

      var minjs = {
       id: null,
       opc : null
    }


    if(req.session.ide){
        
       minjs.id = req.session.ideaux ;
    } 

     if (req.session.ideaux){

           if(req.session.ideaux != null){

               minjs.opc = req.session.ideaux ;

           }

           req.session.ideaux == null;
         
     }


  
   listado.mostraropciones(minjs,(x)=>{
        
        req.session.index = 4 ;
        req.session.opciones = x ;

       if(req.session.ide){
          
          listado.consultarcuentas(req.session.ide,(y)=>{

              req.session.config.lista = listacorta(x,req); ;
              req.session.config.cuentas = y;
              res.render(DireccionPaginas.EligirAhorro,req.session.config);
              return;

          });
          
           return;
       }
       else{

        let config={
          'name':"Publicar Ahorro",
          'logeadoClass':'notLogged',
          'lista':listacorta(x,req),
          'logeado':false,
          'cuentas':[{num_cuenta : 'INICIE ',nom_banco:'SESSION'}]
        };

        res.render(DireccionPaginas.EligirAhorro,config);
       }
       

    });
 }

static CerrarSession(req,res){
  req.session.destroy();
  // res.statusCode = 302;
   //    res.setHeader('Location', '/' );
   //    res.end();
   res.redirect('/');
   res.end();
 }

static filtro(req,res){

     var url = require("url");

     var num = url.parse(req.url,true).query.num ;
 
      if (!/^([0-9])*$/.test(num)){
         req.session.ideaux = null;

         res.redirect('/QuieroEfectivo');
      }
      else {

         req.session.ideaux = num;

         res.redirect('/QuieroEfectivo');

      }
}

}


module.exports=Primario;


function listacorta(x,req){

      var lista_corta = [];

    if(x.length > 5){

      req.session.bool = true;

        lista_corta.push(x[0]);
          lista_corta.push(x[1]);
            lista_corta.push(x[2]);
              lista_corta.push(x[3]);
                lista_corta.push(x[4]);
  
        return lista_corta;
        
    }
    else {

      req.session.bool = false;

      return x;

    }
}