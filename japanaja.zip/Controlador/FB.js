

class facebookConnection {

   static loginFB(){

   }

   static registarFB(){

   }

}


module.exports = facebookConnection;